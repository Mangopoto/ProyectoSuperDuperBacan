let load = document.querySelector('#preloader');

window.addEventListener('load', ()=>{
  load.style.animation = 'disappear 250ms forwards';
});